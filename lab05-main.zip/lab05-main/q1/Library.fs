module CS334

open System

let rec memberOf (banned: string list) (word: string) =
    match banned with
    | [] -> false
    | b :: banned' ->
        System.String.Equals(b, word, System.StringComparison.CurrentCultureIgnoreCase)
        || memberOf (banned') (word)


let censor (banned: string list) (words: string list) =
    List.map (fun x -> if memberOf (banned) (x) then "xxxx" else x) words
