﻿open CS334
open System

[<EntryPoint>]
let main args =
    if args.Length < 2 then
        printfn "Usage: <banned.txt> <word_1> [... <word_n>]"
        1
    else
        let filter =
            try
                IO.File.ReadLines(args.[0]) |> Seq.toList
            with :? System.IO.FileNotFoundException ->
                printfn "no file was found!"
                exit (1)

        let sentence = args[1..] |> Array.toList
        let answer = System.String.Join(" ", censor filter sentence)
        printfn "%A" answer
        0
