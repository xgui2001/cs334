﻿open CS334

[<EntryPoint>]
let main args = 
  let input = int args.[0]
  let sum = sumSquares(input)
  if args.Length > 1 then
    printfn "Usage: dotnet run <n>"
  else
    printfn "%d" sum
  0