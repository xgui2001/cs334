module CS334
open System

let rec sumSquares(n: int): int = 
  if n = 0 then
    0
  else if n = 1 then
    1
  else
    n * n + sumSquares(n-1)

