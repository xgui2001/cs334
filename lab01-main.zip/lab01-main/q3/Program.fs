﻿open System

[<EntryPoint>]
let main args =
  if args.Length < int args.[0] then
    printfn "Usage: dotnet run <n> <arg_1> .. <arg_n>"
  else
    printfn "%s" args.[int args.[0]]
  0