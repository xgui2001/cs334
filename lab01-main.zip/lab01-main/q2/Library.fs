module CS334
open System


let r = System.Random()
let num = r.Next 2

let result = if num = 0 then "tails" else "heads"
