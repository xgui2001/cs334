﻿open CS334

[<EntryPoint>]
let main args =
  printfn "%s" result
  0