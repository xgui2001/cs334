# Lab 1: Intro to F#

You can find the [lab writeup here](lab-1.pdf)

