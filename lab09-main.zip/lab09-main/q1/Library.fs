module CS334

open Combinator
open System

(*
  A simple parser that parses in a lambda calculus expression and returns its abstract syntax tree.
*)

// constructs an Expr type; it could be a Variable of char type, an Abstraction of char * Expr type, or an Application of Expr * Expr type.
type Expr =
    | Variable of char
    | Abstraction of char * Expr
    | Application of Expr * Expr

// a declaration for a parser called expr and an implementation for that same parser called exprImpl.
// takes in an Input type and returns Outcome <Expr> type.
let expr, exprImpl = recparser ()

// a declaration for a variable parser that parses in a char and returns a Variable. Return type is of Parser<Expr>
let variable: Parser<Expr> = pletter |>> (fun a -> Variable(a))

// a helper function for the abstraction parser that parses in the left side (char) and right side (Expr) of an abstraction and returns an Abstraction. Return type is of Parser<Expr>
let helperabs: Parser<Expr> =
    pseq (pleft pletter (pchar '.')) (expr) (fun (a, b) -> Abstraction(a, b))

// a declaration for an abstraction parser that parses in either L or the Lambda character and calls on the helper function to make an Abstraction. Return type is of Parser<Expr>
let abstraction: Parser<Expr> =
    pbetween (pstr "(L" <|> pstr "(λ") (pchar ')') helperabs

// a declaration for an application parser that parses in two Exprs and combine them into an Application. Return type is of Parser<Expr>
let application: Parser<Expr> =
    pbetween (pchar '(') (pchar ')') (pseq expr expr (fun (a, b) -> Application(a, b)))

// a declaration for a grammar parser that takes in an expr and checks whether it has reached the end of the input. Return type is of Parser<Expr>
let grammar = pleft expr peof

// a parser that parses in a string with our grammar parser; if it was successfully parsed, return an Expr.
// otherwise return none
let parse input : Expr option =
    match grammar (prepare input) with
    | Success (ws, _) -> Some ws
    | Failure (_, _) -> None

// an implementation for the expr parser that determines whether to use the variable parser, the abstraction parser or the application parser.
exprImpl := (variable) <|> (abstraction) <|> (application)

// a print function for our ast that takes in an Expr, matches it with its corresponding constructor and returns a string with correct syntax.
let rec prettyprint (e: Expr) : string =
    match e with
    | Variable a -> "Variable(" + a.ToString() + ")"
    | Abstraction (a, b) -> "Abstraction(" + "Variable(" + a.ToString() + ")" + ", " + prettyprint b + ")"
    | Application (a, b) -> "Application(" + prettyprint a + ", " + prettyprint b + ")"
