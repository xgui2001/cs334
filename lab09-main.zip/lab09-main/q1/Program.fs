﻿open CS334

// parse the command line string input with our parser; if it was successfully parsed, use prettyprint to print the ast out
// otherwise tells the user the program input is invalid
[<EntryPoint>]
let main argv =
    match parse argv.[0] with
    | Some ast -> printfn "%s" (prettyprint ast)
    | None -> printfn "Invalid program :("

    0
