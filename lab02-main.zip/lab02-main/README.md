# Lab 2: More F#

You can find the [lab writeup here](lab-2.pdf)

