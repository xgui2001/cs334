﻿open CS334

(*
* Given a non-empty tree, returns a new tree that has the same structure 
* as the original but with the function f applied to the values stored in the original tree.
*
* @param f The function; t The tree.
* @return a new tree with the function f applied to the values of the original tree.
* 
* the return val is val maptree: f: ('a -> 'b) -> t: Tree<'a> -> Tree<'b>. Because we don't
* exactly know what the function does to the values that have been passed in, we shouldn't assume the 
* the values' types stay the same (they might have been changed by the function).
*)

[<EntryPoint>]
let main args = 
  let result = maptree f t
  let result2 = maptree f2 t2
  let result3 = maptree f3 t3
  printfn "%A" result
  printfn "%A" result2
  printfn "%A" result3
  0
