module CS334
open System

type Tree<'a> =
 | Leaf of 'a
 | Node of Tree<'a> * Tree<'a>

let f x = x + 1
let t = (Node (Node (Leaf 2, Leaf 3), Leaf 4))

let f2 y = y * 2
let t2 = (Node (Node (Node (Leaf 2, Leaf 3), Leaf 4), Leaf 5))

let f3 z = z - 1
let t3 = (Node (Leaf 0, Leaf 1))

let rec maptree f t = 
  match t with 
  | Leaf a -> Leaf (f a)
  | Node (a, b) -> Node (maptree f a, maptree f b)