﻿open CS334

[<EntryPoint>]
let main args = 
  printfn "%A" (zip [1;3;5;7] ["a";"b";"c";"d"])
  printfn "%A" (zip [1;3] ["a";"b";"c";"d"])
  printfn "%A" (zip [1;3;5;7] [])
  printfn "%A" (zip [] ["a";"b";"c";"d"])
  printfn "%A" (unzip [(1,"a"); (3,"b") ;(5,"c"); (7,"de")])
  printfn "%A" (unzip [])
  printfn "%A" (zip3 [1;3;5;7] ["a";"b";"c";"de"] [1;2;3;4])
  printfn "%A" (zip3 [1;3;5] ["a";"b";"c";"de"] [1;2;3;4])
  printfn "%A" (zip3 [1;3;5] ["a";"b";"c";"de"] [1;2;3])
  printfn "%A" (zip3 [] ["a";"b";"c";"de"] [1;2;3])
  printfn "%A" (zip3 [] [] [1;2;3])
  printfn "%A" (zip3 [] [] [])
  0
  