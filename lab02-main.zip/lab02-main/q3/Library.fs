module CS334
open System

let rec zip (xs) (ys): ('a*'b) list = 
  match xs, ys with
  | [], [] -> []
  | [], _ -> []
  | _, [] -> []
  | [x], _ -> List.map (fun y -> (x,y)) ys
  | _, [y] -> List.map (fun x -> (x,y)) xs
  | x::xs', y::ys' -> (x,y) :: zip xs' ys'

let rec unzip(xs) : 'a list * 'b list =
  match xs with
  | [] -> [], []
  | (x,y)::xs' -> 
    let (a, b) = unzip xs' 
    (x::a, y::b)

//tuple of lists

let rec zip3(xs: 'a list)(ys: 'b list)(zs: 'c list) : ('a * 'b * 'c) list = 
  let zip3_1 = zip xs ys
  let zip3_2 = zip zip3_1 zs
  List.map (fun ((x,y),z) -> (x,y,z)) zip3_2

  