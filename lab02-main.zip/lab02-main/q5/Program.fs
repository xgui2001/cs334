﻿open CS334

(*
* Given a non-empty tree, returns a value that combines 
* all the values of the leaves using the operation passed as the first parameter.
*
* @param f The function; t The tree.
* @return a value that combines all the values of the leaves through f.
*
*)

[<EntryPoint>]
let main args = 
  let result = treduce f t
  let result2 = treduce f2 t2
  let result3 = treduce f3 t3
  printfn "%A" result
  printfn "%A" result2
  printfn "%A" result3
  0