module CS334
open System

type Tree<'a> =
 | Leaf of 'a
 | Node of Tree<'a> * Tree<'a>

let f x y = x + y
let t = (Node (Node (Leaf 1, Leaf 2), Leaf 3))

let f2 x y = x * y
let t2 = (Node (Node (Node (Leaf 0, Leaf 1), Leaf 2), Leaf 3))

let f3 x y = x / y
let t3 = (Node (Leaf 4, Leaf 4))

let rec treduce f t = 
  match t with 
  | Leaf a -> a
  | Node (a, b) -> f (treduce f a) (treduce f b)