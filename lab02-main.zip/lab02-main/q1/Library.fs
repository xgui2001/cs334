module CS334
open System

let rec pbj(n: int) : string =
  match n % 3 = 0, n % 5 = 0, n < 3 with
  | true, false, false -> pbj (n-1) + "peanutbutter "
  | false, true, false -> pbj (n-1) + "jelly "
  | false, false, true ->  ""
  | _, _, _ -> pbj (n-1) + ""

let pbj_helper n = 
  pbj n + "time."