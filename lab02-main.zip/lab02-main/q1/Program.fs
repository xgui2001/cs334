﻿open CS334

[<EntryPoint>]
let main args =
  if args.Length < 1 then
    printfn "Usage: dotnet run <n>"
  if int args.[0] < 1 then
    printfn "Please put in a positive integer! Usage: dotnet run <n>"
  else
    printfn "%s" (pbj_helper (int args.[0]))
  0