﻿open CS334

[<EntryPoint>]
let main (args: string[]) =
  if args.Length < 1 then
    printfn "Usage: dotnet run <a'> <n>"
  if int args.[1] < 1 then
    printfn "Please put in a positive integer! Usage: dotnet run <a'> <n>"
  else
    printfn "%A" (listDup (args.[0]) (int args.[1]))
  0