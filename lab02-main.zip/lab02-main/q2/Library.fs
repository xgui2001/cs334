module CS334
open System

let rec listDup (e: 'a) (n: int): 'a list =
  if n = 0 then
    []
  else
    e::listDup e (n-1)
    