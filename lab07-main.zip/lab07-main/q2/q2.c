#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
    printf("enter input> ");
    char current;
    char temp[1024];
    char **line = malloc(10000 * sizeof(char *));
    int i = 0;
    int j = 0;
    int totalCount = 0;

    while ((current = getchar()) != EOF)
    {

        if (current == '\n' || i > 1023)
        {
            line[j] = malloc(i * sizeof(char *) + 1);
            temp[i + 1] = '\0';
            // printf("%s", temp);
            strcpy(line[j], temp);
            memset(temp, 0, 1024);
            i = 0;
            j++;
            printf("enter input> ");
        }
        temp[i] = current;
        i++;
    }

    for (int k = 0; k < j; k++)
    {
        if (k == 0)
        {
            printf("\n%lu: %s", strlen(line[k]), line[k]);
            totalCount += strlen(line[k]);
            free(line[k]);
        }
        else
        {
            printf("\n%lu: %s", strlen(line[k]) - 1, line[k]);
            totalCount += strlen(line[k]) - 1;
            free(line[k]);
        }
    }
    free(line);
    printf("\n%d\n", totalCount);

    return 0;
}