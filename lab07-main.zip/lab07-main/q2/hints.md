Here are some hints for this problem:

* The keyboard buffer in most terminals can store at most 1024 characters at a time.  So you may assume that no single entered string is longer than 1024 characters.
* The natural data structure for storing a sequence of unknown length is a linked list, and if you *want* to write a linked list in C, please do.  But you can alternatively assume that the user will never enter more than 10000 lines total into the program.
* Making a 1024 x 10000 byte array (especially an automatic array of that size) is not the right approach, mostly because it is egregiously wasteful of space.  Most strings will probably not be 1024 characters long, and most inputs will not be 10000 lines long.  Use allocated memory, and do your best to be thrify (i.e., no wasted space).
* Lastly: you can either count characters as you read out the strings, or count as you read in the strings.  Both approaches are acceptable.  The second one is more interesting, but requires storing something like an array of tuples.  C does not have tuples.  (Hint: but it does have structs!)

