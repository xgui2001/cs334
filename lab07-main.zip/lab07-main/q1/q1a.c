#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    int n[10];
    int num = rand();

    for (int i = 0; i < 10; i++)
    {
        n[i] = num;
        printf("%d", n[i]);
    }
    return 0;
}