#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    int *n = malloc(10 * sizeof(int));
    int num = rand();

    for (int i = 0; i < 10; i++)
    {
        n[i] = num;
        printf("%d", n[i]);
    }
    free(n);
    return 0;
}