#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
    char *string = malloc(10 * sizeof(char *));

    for (int i = 0; i < 9; i++)
    {
        int num = (rand() % (123 - 97)) + 97;
        string[i] = num;
        // printf("%s \n", &string[i]);
    }
    string[9] = '\0';

    char **stringcopy = malloc(10 * sizeof(char **));
    for (int j = 0; j < 10; j++)
    {
        stringcopy[j] = malloc(10 * sizeof(char));
        strcpy(stringcopy[j], string);
        printf("%s \n", stringcopy[j]);
        free(stringcopy[j]);
    }

    free(string);
    free(stringcopy);
    return 0;
}