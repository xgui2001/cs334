#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
    char string[10];

    for (int i = 0; i < 9; i++)
    {
        int num = (rand() % (123 - 97)) + 97;
        string[i] = num;
        // printf("%s \n", &string[i]);
    }
    string[9] = '\0';

    char stringcopy[10][10];
    for (int j = 0; j < 10; j++)
    {
        strcpy(stringcopy[j], string);
        printf("%s \n", stringcopy[j]);
    }
    return 0;
}