﻿open CS334

[<EntryPoint>]
let main args =
    let result1 = eval (Add(Number 1, Number 5))
    //1+5 = 6
    let result2 = eval (Add(Multiply(Number 5, Number 3), Number 1))
    //1+5*3 = 16
    let result3 = eval (Add(Minus(Divide(Number 6, Number 7), Number 4), Number 1))
    //6/7 − 4 + 1.
    let result4 =
        eval (Divide(Multiply(Minus(Add(Number 5, Number 4), Number 3), Number 2), Number 1))
    //(((5+4) - 3) x 2 )/1 = 12
    printfn "%d" result1
    printfn "%d" result2
    printfn "%d" result3
    printfn "%d" result4
    0
