module CS334

open System

type Expr =
    | Number of int
    | Add of Expr * Expr
    | Minus of Expr * Expr
    | Multiply of Expr * Expr
    | Divide of Expr * Expr

let rec eval (e: Expr) : int =
    match e with
    | Number a -> a
    | Divide (a, b) -> eval a / eval b
    | Multiply (a, b) -> eval a * eval b
    | Minus (a, b) -> eval a - eval b
    | Add (a, b) -> eval a + eval b
